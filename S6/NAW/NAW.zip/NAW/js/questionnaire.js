$(document).ready(
    $.when
    ( 
        loadXML("xml/citations.xml"), 
        loadXML("xml/auteurs.xml")
    ).done
    (
        function(data1, data2)
        {
            getQuotes(data1);
            getAuthors(data2);
        }
    )   
); 

/* function getQuotes()
    {
        var quotesArray = [];
        $.ajax(
            {
                type: "GET",
                url: "xml/citations.xml",
                dataType: "xml",
                success: function(xml)
                    {
                        $(xml).find('citation').each(
                            function(i)
                            {
                                //Création d'un objet pour chaque citation
                                var citation = 
                                    {
                                        auteur: $(this).find('auteur').text(),
                                        theme: $(this).find('theme').text(),
                                        texte: $(this).find('texte').text(),
                                        motcle: $(this).find('motcle').text(),
                                        ouvrage: $(this).find('ouvrage').text();
                                    };
                                
                                //Stockage des citations dans un tableau 
                                quotesArray[i] = citation;
                                
                                
                                //$('<article class="article-solo"></article>').html('<blockquote>' + auteur + '</blockquote><footer class="autor-name">' + auteur + '</footer>').appendTo('#content-main');
                            }
                        );
                    }
            }
        );
        
        return quotesArray;
    }

function getAuthor()
    {
        var authorArray = [];
        $.ajax(
            {
                type: "GET",
                url: "xml/auteurs.xml",
                dataType: "xml",
                success: function(xml)
                    {
                        $(xml).find('auteur').each(
                            function(i)
                            {
                                //Création d'un objet pour chaque auteur 
                                var auteur =
                                    {
                                        nom: $(this).attr('nom'),
                                        naissaince: $(this).attr('naissance'),
                                        deces: $(this).attr('deces'),
                                        pays: $(this).find('pays').text(),
                                        image: $(this).find('image').text(),
                                    };
                                
                                //Stockage des citations dans un tableau 
                                authorArray[i] = auteur;
    
                            }
                        );
                    }
            }
        );
        
        return authorArray;
    }
*/ 

function getQuotes(xml)
{
    var quotes = [];
    $(xml).find('citation').each
    (
        function(i)
        {   
            //Création d'un objet pour chaque citation
            var quote = 
            {
                auteur: $(this).find('auteur').text(),
                theme: $(this).find('theme').text(),
                texte: $(this).find('texte').text(),
                motcle: $(this).find('motcle').text(),
                ouvrage: $(this).find('ouvrage').text()
            };
            
        //Stockage des citations dans un tableau 
        quotes[i] = quote;
        }
    ); 
    
    return quotes;
}

function getAuthors(xml)
{
    var authors = [];
    $(xml).find('auteur').each
    (
        function(i)
        {
            //Création d'un objet pour chaque auteur 
            var author =
            {
                nom: $(this).attr('nom'),
                naissaince: $(this).attr('naissance'),
                deces: $(this).attr('deces'),
                pays: $(this).find('pays').text(),
                image: $(this).find('image').text()
            };
                                
        //Stockage des citations dans un tableau 
        authors[i] = author;
        }
    );
    
    return authors;
}

function loadXML(file)
{
    return $.ajax(
        {
            type: "GET",
            url: file,
            dataType: "xml",
            //success: function(xml) {}  
        }
    )
         
}



                                                                                   
                                    
                                
                                              
                                
                    