//Variables de configurations
var nbrOfQuestions = 10;
var quotes = [];
var authors = [];

$(document).ready(
    $.when
    ( 
        loadXML("xml/citations.xml"), 
        loadXML("xml/auteurs.xml")
    ).done
    (
        function(data1, data2)
        {
            quotes = getQuotes(data1);
            authors = getAuthors(data2);
            
            associate(quotes, authors);
            play();
            
        }
    )   
); 


                                
                                //$('<article class="article-solo"></article>').html('<blockquote>' + auteur + '</blockquote><footer class="autor-name">' + auteur + '</footer>').appendTo('#content-main');
                           
function getQuotes(xml)
{
    var quotes = [];
    $(xml).find('citation').each
    (
        function(i)
        {   
            //Création d'un objet pour chaque citation
            var quote = 
            {
                auteur: $(this).find('auteur').text(),
                theme: $(this).find('theme').text(),
                texte: $(this).find('texte').text(),
                motcle: $(this).find('motcle').text(),
                ouvrage: $(this).find('ouvrage').text()
            };
            
        //Stockage des citations dans un tableau 
        quotes[i] = quote;
        }
    ); 
    
    return quotes;
}

function getAuthors(xml)
{
    var authors = [];
    $(xml).find('auteur').each
    (
        function(i)
        {
            //Création d'un objet pour chaque auteur 
            var author =
            {
                nom: $(this).attr('nom'),
                naissaince: $(this).attr('naissance'),
                deces: $(this).attr('deces'),
                pays: $(this).find('pays').text(),
                image: $(this).find('image').text()
            };
                                
        //Stockage des citations dans un tableau 
        authors[i] = author;
        }
    );
    
    return authors;
}

function loadXML(file)
{
    return $.ajax(
        {
            type: "GET",
            url: file,
            dataType: "xml",
            //success: function(xml) {}  
        }
    )
         
}

function uniqueRandom(size, nbrRand)
{
    var randoms = [];
    while(randoms.length < nbrRand)
    {
        var random = Math.ceil(Math.random()*size)
        var found = false;
        for(var i = 0; i < randoms.length; i++)
        {
            if(randoms[i] == nbrRand)
            {
                found = true;
                break;
            }
        }
        if(!found)
        {
            randoms[randoms.length] = random;
        }
    }
    return randoms;
}

function arrayFind(ele, array)
{
    for(var i = 0; i < array.length; i++)
    {
        if(array[i] == ele)
        {
            return i;
        }
    }
    
    return -1;
}

/*Associe un objet auteur à l'auteur d'une citation, si il existe.
Sinon, crée un objet avec comme seule information le nom */
function associate(quotes, authors)
{
    var nameAuthors = [];
    var indexAuthor = 0;
    
    for(var i = 0; i < authors.length; i++)
    {
        nameAuthors[i] = authors[i].nom.valueOf();  
    }
    
    for(var j = 0; j < quotes.length; j++)
    {
        indexAuthor = arrayFind(quotes[j].auteur, nameAuthors);
        if(indexAuthor != -1)
        {
            quotes[j].auteur = authors[indexAuthor];
        }
        else
        {
            quotes[j].auteur = {
                nom: quotes[j].auteur,
                naissaince: null,
                deces: null,
                pays: null,
                image: null
            };
        }
    } 
}

function createQuestion(nbrOfAnswers, quotes, authors, type)
{ 
    var uniqueIndexAnswsers = [];
    var question = null;
    var label; 
    var answers = [];
    
    switch(type)
    {
            case 0:
                uniqueIndexAnswsers = uniqueRandom(authors.length, nbrOfAnswers);
                
                label = quotes[uniqueRandom(quotes.length, 1)];
            
                answers[0] = label.auteur;
            
                for(var i = 1; i < uniqueIndexAnswsers.length; i++)
                {
                    answers[i] = authors[uniqueIndexAnswsers[i]];
                }
                
                answers = shuffle(answers);
            
                question = 
                {
                    label: label,
                    answers: answers,
                    goodanswers: label.auteur,
                    type: type
                }
                
            
            break;
            
            case 1:

            break;
            
            default: 
    }
    
    return question;
        
}

/* Fisher-Yates shuffles
Permet de melanger les élèments d'un tableau */
function shuffle(array)
{
    var currentIndex = array.length;
    var temp; 
    var randomIndex;
    
    while(0 !== currentIndex)
    {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        
        temp = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temp;
    }
    
    return array;
}

function displayQuestion(question)
{
     $('<article class="article-solo" id="content-survey" ></article>').appendTo('#content-main');
    
    switch(question.type)
    {    
            case 0:
            $('<blockquote>' + question.label.texte + ' </blockquote>').appendTo('#content-survey'); 
            $('<form id="survey"></form>').appendTo('#content-survey');
            
                for(var i = 0; i < question.answers.length; i++)
                {
                    $('<input type="radio" id="' + question.answers[i].nom + '" name="answers" value="' + question.answers[i].nom + '"><label for="' + question.answers[i].nom + '">' + question.answers[i].nom + '</label>').appendTo('#survey');
                    
                }
                
            break;
            
            case 1:
               
            break;
            
            default:
            
            
    }
    
    $('<input type="submit" value="Envoyer" id="survey-submit"/>').appendTo('#content-survey');
    
    //Gestionnaire d'évenement ici pour garantir l'existence du bouton
    $("#survey-submit").click(
    
            function()
            {
                checkAnswer(question);
                if(nbrOfQuestions > 0)
                {
                    $("#content-survey").remove();
                    play();
                }
                else
                {
                    displayScore();
                }
            }
);
}

function play()
{
    var question = createQuestion(3,quotes,authors,0);
    displayQuestion(question);
    nbrOfQuestions--;
}

function checkAnswer(question)
{
    if($("input[type=radio]:checked").val() == question.goodanswers.nom)
    {
        alert('Bravo');
    }
    else
    {
        alert('Dommage');
    }
}





                                                                                   
                                    
                                
                                              
                                
                    