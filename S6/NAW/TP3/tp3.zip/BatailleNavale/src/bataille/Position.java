package bataille;

public class Position {

	public int x;
	public String y;
	
	public Position(int x,String y)
	{
		this.x= x;
		this.y = y;
	}
	
	public int getX()
	{
		return this.x;
	}
	
	public String getY(){
		return this.y;
	}
}
