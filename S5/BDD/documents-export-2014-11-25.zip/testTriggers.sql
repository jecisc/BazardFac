insert into PROJET_adherent values(1,'dupont','Jean','0760606060','dupont.jean@live.fr',TO_DATE('25/07/1979', 'dd/mm/yyyy'));
insert into PROJET_adherent values(1,'dupont','Jean','0760606060','dupont.jean.jr@live.fr',TO_DATE('25/07/1999', 'dd/mm/yyyy'));
INSERT INTO PROJET_ANIMATEUR values(1,'einstein','Albert');
