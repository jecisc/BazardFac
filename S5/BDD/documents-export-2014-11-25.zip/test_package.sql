set serveroutput on;
BEGIN
  pack_adherent.lien_familial(5,9,'soeur');
END;
set serveroutput off;
/
SELECT id_adherent FROM projet_adherent WHERE id_adherent = 25;