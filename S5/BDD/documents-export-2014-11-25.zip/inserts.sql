/* AJOUT ADHERENT (SANS RELATIONS FAMILIALES) */

INSERT INTO PROJET_ADHERENT VALUES(1,'desperaux','Pierre','0761546923','pierre.desperaux@gmail.com',TO_DATE('25/07/1979', 'dd/mm/yyyy'));
INSERT INTO PROJET_ADHERENT VALUES(1,'valjean','Jean','0687369427','jean.valjean.miserable@hotmail.fr',TO_DATE('14/01/1850', 'dd/mm/yyyy'));
INSERT INTO PROJET_ADHERENT VALUES(1,'white','Walter','0725834986','walter.white@live.com',TO_DATE('26/11/1979', 'dd/mm/yyyy'));
INSERT INTO PROJET_ADHERENT VALUES(1,'cook','Thomas','0685972354','cook.thomas.59@gmail.com',TO_DATE('04/09/1984', 'dd/mm/yyyy'));
INSERT INTO PROJET_ADHERENT VALUES(1,'zuckerberg','Marc','0325487961','marc.zuckerberg@facebook.com',TO_DATE('18/12/1990', 'dd/mm/yyyy'));
INSERT INTO PROJET_ADHERENT VALUES(1,'cook','yoan','0985647231','cook.yoan@hotmail.fr',TO_DATE('15/01/1995', 'dd/mm/yyyy'));
INSERT INTO PROJET_ADHERENT VALUES(1,'white','Skyler','0725842986','skyler.white@outlook.com',TO_DATE('13/05/1977', 'dd/mm/yyyy'));

/* AJOUT ACTIVITES (SANS ANIMATEURS) */

INSERT INTO PROJET_ACTIVITE VALUES(1,NULL,'tourisme local',15,TO_DATE('29/11/2014', 'dd/mm/yyyy'),TO_DATE('15:30', 'HH24:MI'),5,TO_DATE('03:30', 'HH24:MI'),20,55);
INSERT INTO PROJET_ACTIVITE VALUES(1,NULL,'tir à la carabine',20,TO_DATE('05/12/2014', 'dd/mm/yyyy'),TO_DATE('15:30', 'HH24:MI'),2,TO_DATE('02:45', 'HH24:MI'),18,80);
INSERT INTO PROJET_ACTIVITE VALUES(1,NULL,'canoë-kayak',30,TO_DATE('05/05/2014', 'dd/mm/yyyy'),TO_DATE('14:00', 'HH24:MI'),9,TO_DATE('05:30', 'HH24:MI'),14,40);
