CREATE OR REPLACE PACKAGE pack_adherent AS
  
  TARIF_ACTIVITE constant Number := 200 ; -- en euros, tarif annuel d'inscription
  REDUCTION constant NUMBER := 10 ; --pourcentage
  
  --Exceptions
  
  PB_LIEN_FAMILIAL Exception ;
  PRAGMA exception_init(PB_LIEN_FAMILIAL, -20110);
  
  ERREUR_AGE Exception ;
  PRAGMA exception_init(ERREUR_AGE, -20111);
  
  GROUPE_PLEIN Exception ;
  PRAGMA exception_init(GROUPE_PLEIN, -20112);
  
  ADHERENT_INCONNU Exception ;
  PRAGMA exception_init(ADHERENT_INCONNU, -20113);
  
  ACTIVITE_INCONNUE Exception ;
  PRAGMA exception_init(ACTIVITE_INCONNUE, -20114);
  
  ERREUR_INSCRIPTION Exception ;
  PRAGMA exception_init(ERREUR_INSCRIPTION, -20115);
  
  --Procedures
  
  procedure lien_familial(un_adherent projet_adherent.id_adherent%type, un_autre projet_adherent.id_adherent%type, lien projet_famille.lien_famillial%type);/*
  
  procedure enlever_lien_familial(un_adherent projet_adherent.id_adherent%type, un_autre projet_adherent.id_adherent%type);
                                 
  procedure inscription(un_adherent adherent.id_adherent%type,
                        une_activite activite.id_activite%type);
                        
  procedure desinscription(un_adherent adherent.id_adherent%type,
                            une_activite activite.id_activite%type);
  */
end pack_adherent;
/
CREATE OR REPLACE PACKAGE BODY pack_adherent AS
  
  --Procedure permettant d'ajouter un lien familiale.
  --Si le lien existe déjà:
  --  si c’est un lien qui a le meme sens (par exemple a1 parent de a2 au lieu de a2 enfant de a1), alors la procedure ne fera rien.
  --  si c’est un lien qui n’a pas le meme sens (par exemple a1 parent de a2 au lieu de a2 frere de a1), alors la procedure declenchera l’exception PB_LIEN_FAMILIAL
  --Si au moins l’un des deux adherents n’existe pas, la procedure declenchera l’exception ADHERENT_INCONNU.
  procedure lien_familial(un_adherent projet_adherent.id_adherent%type, un_autre projet_adherent.id_adherent%type, lien projet_famille.lien_famillial%type) is
    lien_actuel PROJET_FAMILLE.lien_famillial%type;
  begin
    --On vérifie si les adhérents exitent bien.
    /*SELECT id_adherent FROM projet_adherent WHERE id_adherent = un_adherent;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN
          RAISE ADHERENT_INCONNU; --Si un adherent n'existe pas, on utilise une exception
          
    SELECT id_adherent FROM projet_adherent WHERE id_adherent = un_autre;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN
          RAISE ADHERENT_INCONNU; --Si un adherent n'existe pas, on utilise une exception      
          */
    SELECT lien_famillial INTO lien_actuel FROM projet_famille WHERE ((id_adherent = un_adherent AND id_proche = un_autre) OR (id_adherent = un_autre AND id_proche = un_adherent )); 
         
      IF NOT((lien_actuel = 'parent' AND lien = 'enfant') OR (lien_actuel='enfant' AND lien='parent') OR (lien_actuel='conjoint' AND lien = 'conjoint') OR (lien_actuel ='soeur' OR lien_actuel ='soeur' AND lien = 'frere' OR lien_actuel ='soeur'))THEN
        RAISE PB_LIEN_FAMILIAL;
      END IF;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
    --Si aucun lien n'existe déjà, on le crée.
      INSERT INTO PROJET_FAMILLE VALUES(un_adherent, un_autre, lien);
 
   
      
  end lien_familial;
  /*
  --Procedure enlever_lien_familial supprime le lien entre les 2 adhérents (indépendamment de l’ordre entre adh1 et adh2). S’il n’y a aucun lien entre ces 2 adhérents, on déclenche l’exception PB_LIEN_FAMILIAL.
  procedure enlever_lien_familial(un_adherent projet_adherent.id_adherent%type, un_autre projet_adherent.id_adherent%type) is
    lien PROJET_FAMILLE.lien_famillial%type;
    second_lien PROJET_FAMILLE.lien_famillial%type;
  begin
    -- On récupére les liens dans les deux sens.
    SELECT lien_famillial INTO lien FROM projet_famille WHERE(id_adherent = un_adherent AND id_proche = un_autre);
    SELECT lien_famillial INTO second_lien FROM projet_famille WHERE(id_adherent = un_autre AND id_proche = un_adherent);
    
    --On effectue les actions suivant les liens.
    --Si aucun des deux n'existe, on léve une erreur.
    IF(lien IS NULL AND second_lien IS NULL)THEN
      RAISE PB_LIEN_FAMILIAL;
    END IF;
    
    --Si le premier existe, on le supprime.
    IF(NOT(lien IS NULL))THEN
      DELETE FROM projet_famille WHERE (id_adherent = un_adherent AND id_proche = un_autre);
    END IF;
    
    --Si le second existe, on le supprimer.
    IF(NOT(second_lien IS NULL))THEN
      DELETE FROM projet_famille WHERE (id_adherent = un_autre AND id_proche = un_adherent);      
    END IF;
  end enlever_lien_familial;
*/
end pack_adherent;